@echo off
powershell -ExecutionPolicy Bypass -NoProfile -File "%LOCALAPPDATA%\uvnc bvba\UltraVNC\update_ports.ps1"

timeout /t 5 /nobreak >nul
start "" "%LOCALAPPDATA%\uvnc bvba\UltraVNC\winvnc.exe"
