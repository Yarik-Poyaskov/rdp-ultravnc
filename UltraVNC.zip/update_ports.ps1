﻿# Определяем текущего пользователя
$userName = $env:USERNAME

# Проверяем, соответствует ли имя формату "user-N"
if ($userName -match "^user-(\d+)$") {
    $userNumber = [int]$matches[1]

    # Определяем значения портов
    $portNumber = 5900 + $userNumber
    $httpPortNumber = 5800 + $userNumber

    # Определяем путь к файлу ultravnc.ini
    $filePath = "$env:LOCALAPPDATA\uvnc bvba\UltraVNC\ultravnc.ini"

    # Проверяем существование файла
    if (Test-Path $filePath) {
        # Читаем содержимое файла
        $content = Get-Content $filePath -Raw

        # Заменяем параметры
        $content = $content -replace "PortNumber=\d+", "PortNumber=$portNumber"
        $content = $content -replace "HTTPPortNumber=\d+", "HTTPPortNumber=$httpPortNumber"

        # Записываем изменения в файл
        [System.Text.Encoding]::UTF8.GetBytes($content) | Set-Content -Path $filePath -Encoding Byte

        Write-Host "Файл $filePath обновлен: PortNumber=$portNumber, HTTPPortNumber=$httpPortNumber"
    } else {
        Write-Host "Файл $filePath не найден!"
    }
} else {
    Write-Host "Имя пользователя $userName не соответствует формату user-N."
}
